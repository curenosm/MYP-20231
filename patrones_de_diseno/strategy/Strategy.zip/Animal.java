public interface Animal{
	public String mostrarInformacion();
}