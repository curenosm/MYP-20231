public interface Elem{
	public String mostrarInfo();
}