public interface Personaje{
	public String getDescripcion();
	public int getFuerza();
	public int getDestreza();
	public int getSalud();
	public int getInteligencia();
	public int getCarisma();
}