public class Curly extends Papas{
	@Override
	public double precio(){
		return 17;
	}

	@Override
	public String nombre(){
		return "Papas curly";
	}
}