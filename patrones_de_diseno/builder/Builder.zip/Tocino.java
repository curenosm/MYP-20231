public class Tocino extends Hamburguesa{
	@Override
	public double precio(){
		return 34.5;
	}

	@Override
	public String nombre(){
		return "Hamburguesa con Tocino";
	}
}