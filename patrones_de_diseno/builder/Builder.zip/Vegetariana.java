public class Vegetariana extends Hamburguesa{
	@Override
	public double precio(){
		return 25.5;
	}

	@Override
	public String nombre(){
		return "Hamburguesa Vegetariana";
	}
}