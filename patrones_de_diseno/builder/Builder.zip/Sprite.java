public class Sprite extends Bebida{
	@Override
	public double precio(){
		return 15.2;
	}

	@Override
	public String nombre(){
		return "Sprite";
	}
}