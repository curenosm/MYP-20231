public abstract class Bebida implements Componente{

	@Override
	public abstract double precio();

}