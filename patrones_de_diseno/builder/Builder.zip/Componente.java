public interface Componente{
	public String nombre();
	public double precio();
}