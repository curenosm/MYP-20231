public class CocaCola extends Bebida{
	@Override
	public double precio(){
		return 17.4;
	}

	@Override
	public String nombre(){
		return "Coca-Cola";
	}
}