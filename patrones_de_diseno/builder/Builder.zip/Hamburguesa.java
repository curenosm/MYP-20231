public abstract class Hamburguesa implements Componente{

	@Override
	public abstract double precio();

}