public class Francesa extends Papas{
	@Override
	public double precio(){
		return 15.5;
	}

	@Override
	public String nombre(){
		return "Papas a la francesa";
	}
}