public abstract class Papas implements Componente{

	@Override
	public abstract double precio();

}