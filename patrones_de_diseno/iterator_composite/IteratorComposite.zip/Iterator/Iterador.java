public interface Iterador{
	
	public boolean hasNext();

	public Object next();
}