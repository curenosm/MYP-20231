public interface Motor{
	void crearMotor();
	void getTipo();
}