public interface Carroceria{
	void crearCarroceria();
	void getTipo();
}