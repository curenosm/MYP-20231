public abstract class AbstractFactory{
	abstract Object getComponente(String tipoComponente);
}