public interface LLanta{
	void crearLLanta();
	void getTipo();
}