public interface Sujeto{
	public void registrar(CasaCiudadano c);
	public void remover(CasaCiudadano c);
	public void notificar();
}