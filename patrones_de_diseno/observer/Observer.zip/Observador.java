
public interface Observador{
	public void actualizar();
}