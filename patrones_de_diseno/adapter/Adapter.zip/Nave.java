public interface Nave{
	public void impulsar();
	public void frenar();
	public void navegar();
	public void hiperimpulsor();
	public void atacar();
	public void pruebaDeSistemas();
}