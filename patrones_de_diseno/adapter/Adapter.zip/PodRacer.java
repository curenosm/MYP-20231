public class PodRacer{
	public String acelerar(){
		return ("\n***ACELERACION***"
			+ "\nLos sistemas de aceleracion lineal se han activado."
			+ "\nSuspension antigravitacional funcional."
			+ "\nActivando aceleracion del Pod Racer.");
	}

	public String frenar(){
		return ("\n***FRENADO***"
			+ "\nSe ha activado el sistema de desaceleracion del Pod Racer."
			+ "\nLa velocidad se reduce poco a poco hasta un alto total.");
	}

	public String manejar(){
		return ("\n***DIRECCION***"
			+ "\nSistema de direccion del Pod Racer activado."
			+ "\nComprobacion de movimiento estribor y babor."
			+ "\nSistema en linea.");
	}
}