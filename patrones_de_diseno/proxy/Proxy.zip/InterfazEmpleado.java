public interface InterfazEmpleado{
	
	public void reportar();
	public void actualizarDatos(String nRecurso);
}