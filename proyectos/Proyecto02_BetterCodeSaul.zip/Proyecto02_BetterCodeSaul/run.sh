#!/bin/bash
./mvnw package
java -jar ./target/proyecto_2-0.0.1-executable.jar