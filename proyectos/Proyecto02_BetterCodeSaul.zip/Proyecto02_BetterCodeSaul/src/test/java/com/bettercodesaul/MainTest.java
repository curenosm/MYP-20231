package com.bettercodesaul;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class MainTest {

  @Test
  void justAnExample() {
    assertEquals(1, 1);
  }
}
