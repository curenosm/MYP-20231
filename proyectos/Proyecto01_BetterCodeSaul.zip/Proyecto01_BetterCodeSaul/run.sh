#!/bin/bash
./mvnw package
java -jar ./target/proyecto_1-0.0.1-executable.jar